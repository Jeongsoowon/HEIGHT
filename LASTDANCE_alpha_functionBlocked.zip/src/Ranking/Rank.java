package Ranking;

//import java.lang.reflect.Array;
import User.UserDAO;
import User.UserVO;

import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
//import java.util.Collections;
//import java.util.Arrays;

public class Rank {
        private static int yourHeightRank;
        private static int totalNum;
        private static double percentile;
        private static int count= 0;
        public int getCount() {
                return count;
        }

        public static double[] Return_Rank(UserVO uv, UserDAO ud) {
                List<Double> HeightTable = new ArrayList<Double>();
                List<Object> IdTable = new ArrayList<Object>();
                double[] Results = new double[3];
                ud.Insert_DB(uv);
                count++;
                HeightTable = ud.Return_Height(uv);
                count++;
                totalNum = HeightTable.size();
                int yourId = ud.Find_STONE(uv);
                IdTable = ud.Return_Id(uv);

                yourHeightRank = IdTable.indexOf(yourId) + 1;

                percentile = (double)yourHeightRank / (double)totalNum * 100;

                System.out.println("Your Rank is " + yourHeightRank + "(total : " + totalNum + ")");
                System.out.println("percentile : " + percentile + "%");



                ud.Delete_DB(yourId);

                if(yourId == -1) {
                        System.out.println("ERROR: Can't Find User's data.");
                }
                Results[0] = yourHeightRank;
                Results[1] = percentile;
                Results[2] = totalNum;

                return Results;


        }
        public static int[] Return_norm(UserVO uv, UserDAO ud){
                double Max_height = ud.Return_MAX_Height(uv);
                double Min_height = ud.Return_MIN_Height(uv);
                List<Double> HeightTable = new ArrayList<Double>();
                HeightTable = ud.Return_Height_ASC(uv);

                int level_value = 20;
                double Max_Min_height = Max_height- Min_height;
                double[] levels = new double[level_value];
                int[] frequency = new int[level_value];
                for(int i = 0; i < level_value; i++) {
                        if ( i == 0) levels[i] = Min_height + (Max_Min_height/level_value);
                        else {
                                levels[i]= levels[i-1] + (Max_Min_height/level_value);


                        }

                }
                int count = 0;
                for(int j = 0; j < level_value; j++) {
                        for(int i = 0; i< HeightTable.size(); i++) {
                                if (j == 0) {
                                        if (HeightTable.get(i) <= levels[j]) count++;
                                        else break;
                                }
                                else {
                                        if (HeightTable.get(i) <= levels[j] && HeightTable.get(i) >= levels[j-1]) count++;
                                }


                        }
                        frequency[j] = count;
                        count = 0;

                }


                return frequency;
        }

        public static String cutDecimal(int cutSize, double value) {
                NumberFormat nf = NumberFormat.getNumberInstance();
                nf.setMaximumFractionDigits(cutSize);
                nf.setGroupingUsed(false);

                return nf.format(value);
        }


        public static void main(String[] args) {
                int age = 16;
                int sex = 1;
                double height = 174.1;
                UserVO uv = new UserVO(1, sex, age, height, 1);
                UserDAO ud = new UserDAO();
                //int[] k = new int[10];
                //k = Return_norm(uv, ud);
                //int adsf = 0;
                //for(int i = 0; i< 10; i++) {
                //      adsf += k[i];
                //}
                Return_Rank(uv, ud);
                //double[] result = new double[1];
                //result = Return_Rank(uv, ud);
        //      System.out.println(Arrays.toString(Return_norm(uv, ud)));

                //System.out.println("pleaes" + getCount_2());
                //System.out.println(result[0]);
                //System.out.println(result[1]);
                //System.out.println(Return_Rank(uv, ud));
                //System.out.println(Return_Percentile());

        }
}
