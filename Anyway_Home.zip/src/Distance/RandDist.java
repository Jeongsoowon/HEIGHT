package Distance;

import java.util.Arrays;
import java.util.Random;

public class RandDist {
    public static double distance(double lat1, double lon1, double lat2, double lon2, String unit) {

        double theta = lon1 - lon2;
        double dist = Math.sin(deg2rad(lat1)) * Math.sin(deg2rad(lat2)) + Math.cos(deg2rad(lat1)) * Math.cos(deg2rad(lat2)) * Math.cos(deg2rad(theta));

        dist = Math.acos(dist);
        dist = rad2deg(dist);
        dist = dist * 60 * 1.1515;

        if (unit == "kilometer") {
            dist = dist * 1.609344;
        } else if(unit == "meter"){
            dist = dist * 1609.344;
        }

        return (dist);
    }


    public static double[] ReturnCircle(double lat1, double lon1, double DistVal) {
        double[] result = new double[2];


        double theta;
        double dist;
        double latval = 0;
        double lonval = 0;
        Random rand = new Random();
        double count = 0;

        int plma;
        int mapl;
        int errcount = 0;
        while(true) {


                plma = rand.nextInt(2);
                if(plma == 0) plma = -1;
                else { plma = 1;}
                mapl = rand.nextInt(2);
                if(mapl == 0) mapl = -1;
                else { mapl = 1;}
                if(DistVal <= 20.0) {
                        count = 5.0;
                        latval = Math.random() / count * plma;
                        lonval = Math.random() / count * mapl;
                }
                if(DistVal <= 10.0) {
                        count = 10.0;
                        latval = Math.random() / count * plma;
                        lonval = Math.random() / count * mapl;

                }
                else if(DistVal <= 7.0) {
                        count = 17.0;
                        latval = Math.random() / count * plma;
                        lonval = Math.random() / count * mapl;
                }
                else if(DistVal <=  3.0) {
                        count = 35.0;
                        latval = Math.random() / count * plma;
                        lonval = Math.random() / count * mapl;
                }

                double lat2 = lat1 + latval;


                double lon2 = lon1 + lonval;
                theta = lon1 - lon2;
                dist = Math.sin(deg2rad(lat1)) * Math.sin(deg2rad(lat2)) + Math.cos(deg2rad(lat1)) * Math.cos(deg2rad(lat2)) * Math.cos(deg2rad(theta));

                dist = Math.acos(dist);
                dist = rad2deg(dist);
                dist = dist * 60 * 1.1515;
                dist = dist *  1.609344;

                if(dist > DistVal- 1.0 && dist < DistVal + 1.0) {

                        System.out.println("succeess");
                        System.out.println(dist);
                        System.out.println("---------------------------------");
                        System.out.println(latval);
                        System.out.println(lonval);
                        System.out.println("---------------------------------");
                        System.out.println(lat2);
                        System.out.println(lon2);
                        System.out.println("---------------------------------");
                        result[0] = lat2;
                        result[1] = lon2;


                        return result;

                        }
                else {
                        count++;
                        System.out.println("err");
                        errcount++;
                        System.out.println(dist);
                }
                if(errcount == 200) {
                        return result;

                }

        }



    }
    // This function converts decimal degrees to radians
    public static double deg2rad(double deg) {
        return (deg * Math.PI / 180.0);
    }

    // This function converts radians to decimal degrees
    public static double rad2deg(double rad) {
        return (rad * 180 / Math.PI);
    }
    public static void main(String[] args) {
                double homex = 37.2841844956634;
                double homey = 127.913806695921;
                // 37.284611905687036
                // 127.91393973682712
                //double circlex = 37.2841844547634;
                //double circley = 127.912806644721;
                //double distanceMeter = distance(homex, homey, circlex, circley, "meter");
                double circle[];
                //System.out.println(distanceMeter);
                circle = ReturnCircle(homex,homey, 19);
                System.out.println(Arrays.toString(circle));





        }
}




