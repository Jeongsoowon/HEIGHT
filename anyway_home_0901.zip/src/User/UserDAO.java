package User;

import java.sql.*;
//import java.text.SimpleDateFormat;
//import java.util.Date;


import java.util.TreeMap;



public class UserDAO {
	private static String dbURL = "jdbc:mysql://101.101.210.221:3306/AnywayHome?serverTimezone=UTC&useSSL=false&allowPublicKeyRetrieval=true";
    private static String dbID = "PMS";
    private static String dbPassword = "wjdTNT0990!";
    private static Connection conn;
    private static Statement stmt;
    private static ResultSet rs;
    private static PreparedStatement pstmt;
    

    

    

    

    public static TreeMap<Integer, String> Display_DB(){
    	TreeMap<Integer, String> record = new TreeMap<>();

        try {
                Class.forName("com.mysql.jdbc.Driver");
                conn = DriverManager.getConnection(dbURL, dbID, dbPassword);
                stmt = conn.createStatement();

                String sql = "SELECT * FROM record ORDER BY time ASC";

                rs = stmt.executeQuery(sql);


                while(rs.next()) {
                        int id = rs.getInt(1);
                        String Name = rs.getString(2);
                        String birth = rs.getString(3);
                        Integer Time = rs.getInt(4);
                        

                        System.out.println(id + " " + Name + " " + birth +" " + Time + " ");
                        record.put(Time, Name);
                }
        }catch(ClassNotFoundException e) {
                System.out.println("드라이버 로딩 실패");
        }catch(SQLException e) {
                System.out.println("에러" + e);
        }finally {
                try {
                        if(conn != null && !conn.isClosed()) conn.close();
                        if(stmt != null && !stmt.isClosed()) stmt.close();
                        if(rs != null && !rs.isClosed()) rs.close();
                } catch(SQLException e) {
                        e.printStackTrace();
                }
        }
        	return record;
        }
        

        public static void Insert_User(UserVO user) {
            try {
                    Class.forName("com.mysql.jdbc.Driver");
                    conn = DriverManager.getConnection(dbURL, dbID, dbPassword);

                    

                    



                    String sql = "INSERT INTO record (name, birth, time) VALUES (?, ?, ?)";
                    pstmt = conn.prepareStatement(sql);

                    //pstmt.setInt(1, user.getUserId());
                    pstmt.setString(1, user.getUserName());
                    pstmt.setString(2, user.getUserBirth());
                    pstmt.setInt(3, user.getUserTime());
         


                    int count = pstmt.executeUpdate();
                    if(count == 0) System.out.println("데이터 입력 실패");
                    else System.out.println("데이터 입력 성공");
            }catch(ClassNotFoundException e) {
                    System.out.println("드라이버 로딩 실패");
            }catch(SQLException e) {
                    System.out.println("에러" + e);
            }finally {
                    try{
            if( conn != null && !conn.isClosed()){
                conn.close();
            }
            if( pstmt != null && !pstmt.isClosed()){
                pstmt.close();
            }
        }
        catch( SQLException e){
            e.printStackTrace();
        }
            }

    }


    public static void main(String[] args) {
    	UserVO vo = new UserVO(0, "adsf", "980908", 100201);
    	Insert_User(vo);
    	TreeMap<Integer, String> record = new TreeMap<>();
        record = Display_DB();
        // 중복이 문제라면 TreeMap<String, List<Integer>> 이딴 식으로 해도 되는거 아냐? 근데 일단은 여기까지만 할
        for(int i : record.keySet()) {
        	System.out.println("[Time]:" + i + "[Name]:" + record.get(i));
        }
}
}