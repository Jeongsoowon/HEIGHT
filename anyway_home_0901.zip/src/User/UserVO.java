package User;

public class UserVO {
	private int userId;
	private String userName;
	private String userBirth;
	private int userTime;
	

	

	public UserVO(int userId, String userName, String userBirth, int userTime) {
		this.userId = userId;
		this.userName = userName;
		this.userBirth = userBirth;
		this.userTime = userTime;

	}


	public int getUserId() {
		return userId;
	}


	public void setUserId(int userId) {
		this.userId = userId;
	}


	public String getUserName() {
		return userName;
	}


	public void setUserName(String userName) {
		this.userName = userName;
	}


	public String getUserBirth() {
		return userBirth;
	}


	public void setUserBirth(String userBirth) {
		this.userBirth = userBirth;
	}


	public int getUserTime() {
		return userTime;
	}


	public void setUserTime(int userTime) {
		this.userTime = userTime;
	}
	

}
