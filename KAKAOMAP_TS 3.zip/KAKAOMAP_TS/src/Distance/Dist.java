package Distance;

import java.util.Arrays;

public class Dist {
	
	
	    /**
	     * 두 지점간의 거리 계산
	     *
	     * @param lat1 지점 1 위도
	     * @param lon1 지점 1 경도
	     * @param lat2 지점 2 위도
	     * @param lon2 지점 2 경도
	     * @param unit 거리 표출단위
	     * @return
	     */
	    public static double distance(double lat1, double lon1, double lat2, double lon2, String unit) {
	         
	        double theta = lon1 - lon2;
	        double dist = Math.sin(deg2rad(lat1)) * Math.sin(deg2rad(lat2)) + Math.cos(deg2rad(lat1)) * Math.cos(deg2rad(lat2)) * Math.cos(deg2rad(theta));
	         
	        dist = Math.acos(dist);
	        dist = rad2deg(dist);
	        dist = dist * 60 * 1.1515;
	         
	        if (unit == "kilometer") {
	            dist = dist * 1.609344;
	        } else if(unit == "meter"){
	            dist = dist * 1609.344;
	        }
	 
	        return (dist);
	    }
	     
	    public static double[] ReturnCircle(double lat1, double lon1, double DistVal) {
	    	double[] result = new double[2];
	    	
	  
	    	double theta;
	    	double dist;
	    	double latval;
	    	double lonval;
	    	for(int i = 0; i < 50; i++) {
	    		if(DistVal == 2.0) {
	    			latval = Math.random() / 60.0;
	    			lonval = Math.random() / 60.0;
	    		}
	    		else {
	    			latval = Math.random() / 30.0;
	    			lonval = Math.random() / 30.0;
	    			
	    		}
	    			
	    		double lat2 = lat1 + latval;
	    		double lon2 = lon1 + lonval;
	    		theta = lon1 - lon2;
		        dist = Math.sin(deg2rad(lat1)) * Math.sin(deg2rad(lat2)) + Math.cos(deg2rad(lat1)) * Math.cos(deg2rad(lat2)) * Math.cos(deg2rad(theta));
		         
		        dist = Math.acos(dist);
		        dist = rad2deg(dist);
		        dist = dist * 60 * 1.1515;
		        dist = dist *  1.609344;
		        
		        if(dist > DistVal- 0.235 && dist < DistVal + 0.235) {
		        	System.out.println("succeess"); 
		        	System.out.println(dist);
		        	System.out.println(lat2);
		        	System.out.println(lon2);
		        	result[0] = lat2;
			    	result[1] = lon2;
			    	
			    	
			    	return result;
		        
		        	}
		        else {
		        	System.out.println("err");
		        	System.out.println(dist);
		        }
		        
	    		
	    	}
			return result;
	    	
	    	
	    }
	    // This function converts decimal degrees to radians
	    public static double deg2rad(double deg) {
	        return (deg * Math.PI / 180.0);
	    }
	     
	    // This function converts radians to decimal degrees
	    public static double rad2deg(double rad) {
	        return (rad * 180 / Math.PI);
	    }
	    public static void main(String[] args) {
			double homex = 37.2841844956634;
			double homey = 127.913806695921;
			//double distanceMeter = distance(homex, homey, circlex, circley, "meter");
			double circle[];
			
			circle = ReturnCircle(homex,homey, 2.0);
			System.out.println(Arrays.toString(circle));
			
		}
	 
	
}
