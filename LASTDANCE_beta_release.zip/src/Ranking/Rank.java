package Ranking;

//import java.lang.reflect.Array;
import User.UserDAO;
import User.UserVO;
import java.util.HashMap;

import java.text.NumberFormat;
import java.util.ArrayList;

import java.util.List;
import java.util.TreeMap;
import java.util.Arrays;



public class Rank {
	


	private static Double yourHeightRank;
	private static Double totalNum;
	private static Double percentile;
	private static HashMap<String, Double> AllResult = new HashMap<>();
	

	

	

	public static double[] Return_Rank(UserVO uv, UserDAO ud) {
		

		List<Double> HeightTable = new ArrayList<Double>();
		List<Object> IdTable = new ArrayList<Object>();
		double[] Results = new double[3];
		ud.Insert_DB(uv);
		

		HeightTable = ud.Return_Height(uv);
		

		

		

		totalNum = (double) HeightTable.size();
		int yourId = ud.Find_STONE(uv);
	

		IdTable = ud.Return_Id(uv);
		

		yourHeightRank = (double) (IdTable.indexOf(yourId) + 1);
		

	

		

		

		

		percentile = (double)yourHeightRank / (double)totalNum * 100;
		

		System.out.println("Your Rank is " + yourHeightRank + "(total : " + totalNum + ")");
		System.out.println("percentile : " + percentile + "%");
		

		

		

		ud.Delete_DB(yourId, uv);
		

		

		

		if(yourId == -1) {
			System.out.println("ERROR: Can't Find User's data.");
		}
		Results[0] = yourHeightRank;
		Results[1] = percentile;
		Results[2] = totalNum;
		

		AllResult.put("rank", yourHeightRank);
		AllResult.put("perc", percentile);
		AllResult.put("totN", totalNum);
		

		

		return Results;
		

		

	}
	public static TreeMap<Integer, Integer> Return_norm(UserVO uv, UserDAO ud){
		TreeMap<Integer, Integer> ResultNorm = new TreeMap<>();
		ResultNorm.clear();
		

		List<Double> HeightTable = new ArrayList<Double>();
		HeightTable = ud.Return_Height_ASC(uv);
		int MeanHeight = 0;
		double totalHeight = 0;
		for (int i = 0; i< HeightTable.size(); i++) {
			totalHeight += HeightTable.get(i);
		}
		MeanHeight = (int)(totalHeight)/HeightTable.size();
		int level_value = 20;
		

		int[] levels = new int[level_value];
		int[] frequency = new int[level_value];
		for(int i = 0; i < level_value; i++) {
			if ( i == 0) levels[i] =MeanHeight - 20;
			else {
				levels[i]= levels[i-1] + 2;
				

				

			}
			

		}
		int count = 0;
		for(int j = 0; j < level_value; j++) {
			for(int i = 0; i< HeightTable.size(); i++) {
				if (j == 0) {
					if (HeightTable.get(i) <= levels[j]) count++;
					else break;
				}
				else {
					if (HeightTable.get(i) <= levels[j] && HeightTable.get(i) >= levels[j-1]) count++;
				}
			

			

			}
			frequency[j] = count;
			count = 0;
			

		}
		for(int i = 0; i< level_value; i++) {
			ResultNorm.put(levels[i], frequency[i]);
		}
		//Object[] mapkey = ResultNorm.keySet().toArray();
		//Arrays.sort(mapkey);
		System.out.println("System return Norms");
		return ResultNorm;
		

	}
 	

	public static String cutDecimal(int cutSize, double value) {
		NumberFormat nf = NumberFormat.getNumberInstance();
		nf.setMaximumFractionDigits(cutSize);
		nf.setGroupingUsed(false);
		

		return nf.format(value);
	}
	

	

	public static void main(String[] args) {
		int age = 16;
		int sex = 1;
		double height = 174.1;
		UserVO uv = new UserVO(1, sex, age, height, 1);
		UserDAO ud = new UserDAO();
		TreeMap<Integer, Integer> km = new TreeMap<>();
		//int[] k = new int[20];
		km = Return_norm(uv, ud);
		//int adsf = 0;
		//for(int i = 0; i< 20; i++) {
	//		adsf += k[i];
	//	}
		

		//Return_Rank(uv, ud);
		

		//double[] result = new double[1];
		//result = Return_Rank(uv, ud);
		//for(Integer key : km.keySet()) {
		//	Integer value = km.get(key);
	//	System.out.println(key+" : " + value);
			

	//	}
		System.out.println(km);
	

		//System.out.println("pleaes" + getCount_2());
		//System.out.println(result[0]);
		//System.out.println(result[1]);
		//System.out.println(Return_Rank(uv, ud));
		//System.out.println(Return_Percentile());
		

	}
}
